<div class="container-fluid">
    <div class="row-fluid">
        <div class="panel panel-red">
            <div class="panel-heading">
                <i class="fa fa-warning"></i> Error 404: Page not found
            </div>
            <div class="panel-body text-center">
                <font style="color: #D9534F"><i class="fa fa-5x fa-warning"></i></font><br>
                <h3>Halaman yang anda tuju tidak terdapat pada sistem.<br>Item mungkin telah dihapus atau anda salah memasukkan alamat.</h3>
            </div>
        </div>
    </div>
</div>