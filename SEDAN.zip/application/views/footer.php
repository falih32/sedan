<nav class="navbar navbar-default navbar-bottom">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">SEDAN</a>
    </div>
    <div id="navbar" class="collapse navbar-collapse">
    	<p class="navbar-text navbar-right">SISTEM INFORMASI PENGADAAN ELEKTRONIK | BIRO UMUM SEKRETARIAT JENDERAL KEMENTERIAN KELAUTAN DAN PERIKANAN</p>
    </div>
  </div>
</nav>